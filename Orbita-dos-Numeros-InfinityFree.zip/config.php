<?php
declare(strict_types=1);

return [
    // Preencha com os dados exibidos na seção MySQL Databases do painel InfinityFree.
    'db_host' => '',
    'db_port' => '3308',
    'db_name' => '',
    'db_user' => '',
    'db_password' => '',
];
